const express=require("express");
const fs=require("fs");
const path=require("path");
const crypto=require("crypto");

const app=express();
const PORT=process.env.PORT||3000;
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||"673634078162";
const REGISTER_URL="https://www.shreewin55.com/#/register?invitationCode=86286195967";
const HISTORY_URL="https://draw.ar-lottery01.com/WinGo/WinGo_1M/GetHistoryIssuePage.json";

const DATA_DIR=path.join(__dirname,"data");
const UID_FILE=path.join(DATA_DIR,"uids.json");
const REQUEST_FILE=path.join(DATA_DIR,"uid_requests.json");

app.use(express.json({limit:"100kb"}));
app.use(express.urlencoded({extended:false}));

function ensureFiles(){
 if(!fs.existsSync(DATA_DIR))fs.mkdirSync(DATA_DIR,{recursive:true});
 if(!fs.existsSync(UID_FILE))fs.writeFileSync(UID_FILE,"[]","utf8");
 if(!fs.existsSync(REQUEST_FILE))fs.writeFileSync(REQUEST_FILE,"[]","utf8");
}
function readJSON(file){ensureFiles();try{const x=JSON.parse(fs.readFileSync(file,"utf8"));return Array.isArray(x)?x:[]}catch(e){return[]}}
function writeJSON(file,x){ensureFiles();fs.writeFileSync(file,JSON.stringify(x,null,2),"utf8")}
function readUIDs(){return readJSON(UID_FILE)}
function writeUIDs(x){writeJSON(UID_FILE,x)}
function readRequests(){return readJSON(REQUEST_FILE)}
function writeRequests(x){writeJSON(REQUEST_FILE,x)}
function validUID(x){return /^\d{5,8}$/.test(String(x||""))}
function validDeviceId(x){return typeof x==="string"&&x.length>=8&&x.length<=200}
function cleanExpired(x){const now=Date.now();return x.filter(v=>v&&v.uid&&Number(v.expiresAt)>now)}
function saveCleanUIDs(){const x=cleanExpired(readUIDs());writeUIDs(x);return x}
ensureFiles();

const adminTokens=new Map();
function createAdminToken(){const t=crypto.randomBytes(32).toString("hex");adminTokens.set(t,{createdAt:Date.now()});return t}
function validAdmin(t){
 if(!t||!adminTokens.has(t))return false;
 const s=adminTokens.get(t);
 if(Date.now()-s.createdAt>12*60*60*1000){adminTokens.delete(t);return false}
 return true
}
function requireAdmin(req,res,next){
 const a=req.headers.authorization||"";
 if(!a.startsWith("Bearer ")||!validAdmin(a.slice(7)))
  return res.status(401).json({ok:false,message:"Admin login required."});
 next();
}

app.get("/api/status",(req,res)=>res.json({ok:true,name:"AMBIKA PANE AI",serverTime:Date.now()}));
app.get("/api/config",(req,res)=>res.json({ok:true,registerUrl:REGISTER_URL}));

app.post("/api/admin/login",(req,res)=>{
 if(String(req.body?.password||"")!==ADMIN_PASSWORD)
  return res.status(401).json({ok:false,message:"Invalid admin password."});
 const token=createAdminToken();
 res.json({ok:true,token,message:"Admin login successful."});
});
app.post("/api/admin/logout",requireAdmin,(req,res)=>{
 adminTokens.delete((req.headers.authorization||"").slice(7));
 res.json({ok:true,message:"Logged out successfully."});
});
app.get("/api/admin/uids",requireAdmin,(req,res)=>{
 const list=saveCleanUIDs();res.json({ok:true,count:list.length,uids:list});
});

/* MEMBER UID REQUEST */
app.post("/api/access/request",(req,res)=>{
 const uid=String(req.body?.uid||"").trim(),deviceId=String(req.body?.deviceId||"").trim();
 if(!validUID(uid))return res.status(400).json({ok:false,message:"Invalid UID."});
 if(!validDeviceId(deviceId))return res.status(400).json({ok:false,message:"Invalid device ID."});

 const active=saveCleanUIDs().find(x=>x.uid===uid);
 if(active&&(!active.deviceId||active.deviceId===deviceId))
  return res.json({ok:true,alreadyActive:true,message:"UID is already active."});

 let requests=readRequests();
 const existing=requests.find(x=>x.uid===uid&&x.deviceId===deviceId&&x.status==="pending");
 if(existing){
  existing.lastSeenAt=Date.now();writeRequests(requests);
  return res.json({ok:true,pending:true,message:"UID request is already waiting for admin approval."});
 }
 requests.push({uid,deviceId,requestedAt:Date.now(),lastSeenAt:Date.now(),status:"pending"});
 writeRequests(requests.slice(-500));
 res.json({ok:true,pending:true,message:"UID submitted to admin."});
});

app.get("/api/admin/requests",requireAdmin,(req,res)=>{
 const requests=readRequests().filter(x=>x.status==="pending");
 res.json({ok:true,count:requests.length,requests});
});
app.post("/api/admin/requests/reject",requireAdmin,(req,res)=>{
 const uid=String(req.body?.uid||"").trim(),deviceId=String(req.body?.deviceId||"").trim();
 let requests=readRequests(),changed=false;
 requests=requests.map(x=>{
  if(x.uid===uid&&(!deviceId||x.deviceId===deviceId)&&x.status==="pending"){
   changed=true;return {...x,status:"rejected",rejectedAt:Date.now()};
  }
  return x;
 });
 writeRequests(requests);res.json({ok:true,changed});
});

/* UID ACTIVATION */
app.post("/api/admin/activate",requireAdmin,(req,res)=>{
 const uid=String(req.body?.uid||"").trim(),hours=Number(req.body?.hours);
 if(!validUID(uid))return res.status(400).json({ok:false,message:"UID must contain 5 to 8 digits."});
 if(hours!==1&&hours!==24)return res.status(400).json({ok:false,message:"Duration must be 1 or 24 hours."});

 let list=saveCleanUIDs(),old=list.find(x=>x.uid===uid);
 if(old&&old.deviceId)return res.status(409).json({ok:false,message:"This UID is already active and bound to another device.",uid});

 const now=Date.now(),requests=readRequests(),pending=requests.find(x=>x.uid===uid&&x.status==="pending");
 const record={uid,deviceId:pending?pending.deviceId:null,activatedAt:now,expiresAt:now+hours*60*60*1000,durationHours:hours};
 list=list.filter(x=>x.uid!==uid);list.push(record);writeUIDs(list);

 writeRequests(requests.map(x=>x.uid===uid&&x.status==="pending"?{...x,status:"approved",approvedAt:now}:x));
 res.json({ok:true,message:`UID activated for ${hours===1?"1 hour":"24 hours"}.`,record});
});

app.post("/api/admin/lock",requireAdmin,(req,res)=>{
 const uid=String(req.body?.uid||"").trim();
 if(!validUID(uid))return res.status(400).json({ok:false,message:"Invalid UID."});
 let list=saveCleanUIDs(),before=list.length;list=list.filter(x=>x.uid!==uid);writeUIDs(list);
 res.json({ok:true,removed:list.length!==before,message:list.length!==before?"UID locked successfully.":"UID was not found."});
});
app.post("/api/admin/lock-all",requireAdmin,(req,res)=>{
 writeUIDs([]);res.json({ok:true,message:"All UIDs locked successfully."});
});

/* ACCESS CHECK */
app.post("/api/access/check",(req,res)=>{
 const uid=String(req.body?.uid||"").trim(),deviceId=String(req.body?.deviceId||"").trim();
 if(!validUID(uid))return res.status(400).json({ok:false,active:false,approved:false,message:"Invalid UID."});
 if(!validDeviceId(deviceId))return res.status(400).json({ok:false,active:false,approved:false,message:"Invalid device ID."});

 let list=saveCleanUIDs(),record=list.find(x=>x.uid===uid);
 if(!record)return res.json({ok:true,active:false,approved:false,message:"UID is not active."});
 if(Number(record.expiresAt)<=Date.now()){
  writeUIDs(list.filter(x=>x.uid!==uid));
  return res.json({ok:true,active:false,approved:false,message:"UID access has expired."});
 }
 if(!record.deviceId){
  record.deviceId=deviceId;writeUIDs(list);
  return res.json({ok:true,active:true,approved:true,claimed:true,uid:record.uid,expiresAt:record.expiresAt,message:"UID approved and device bound."});
 }
 if(record.deviceId===deviceId)
  return res.json({ok:true,active:true,approved:true,claimed:false,uid:record.uid,expiresAt:record.expiresAt,message:"UID access approved."});
 return res.status(403).json({ok:true,active:false,approved:false,deviceMismatch:true,message:"This UID is already bound to another device."});
});

app.post("/api/access/status",(req,res)=>{
 const uid=String(req.body?.uid||"").trim(),deviceId=String(req.body?.deviceId||"").trim();
 if(!validUID(uid)||!validDeviceId(deviceId))return res.json({ok:true,active:false});
 const record=saveCleanUIDs().find(x=>x.uid===uid);
 if(!record||Number(record.expiresAt)<=Date.now())return res.json({ok:true,active:false});
 if(record.deviceId&&record.deviceId!==deviceId)return res.json({ok:true,active:false});
 res.json({ok:true,active:true,uid:record.uid,expiresAt:record.expiresAt});
});

/* HISTORY PROXY */
let historyCache=null,historyCacheTime=0;
async function fetchLiveHistory(){
 const url=HISTORY_URL+(HISTORY_URL.includes("?")?"&":"?")+"_t="+Date.now();
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);
 try{
  const r=await fetch(url,{method:"GET",signal:controller.signal,headers:{
   "Accept":"application/json,text/plain,*/*",
   "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36",
   "Referer":"https://draw.ar-lottery01.com/"
  }});
  if(!r.ok)throw new Error("History API HTTP "+r.status);
  const text=await r.text();if(!text.trim())throw new Error("Empty history response.");
  let data;try{data=JSON.parse(text)}catch(e){throw new Error("Invalid history JSON.")}
  historyCache=data;historyCacheTime=Date.now();return data;
 }finally{clearTimeout(timer)}
}
app.get("/api/history",async(req,res)=>{
 try{return res.json(await fetchLiveHistory())}
 catch(e){
  console.error("LIVE HISTORY ERROR:",e.message);
  if(historyCache)return res.json({...historyCache,cached:true,cacheTime:historyCacheTime});
  return res.json({success:false,data:{list:[]},message:"Live result connection temporarily unavailable."});
 }
});

app.get("/health",(req,res)=>res.status(200).json({ok:true,status:"healthy",time:new Date().toISOString()}));

const publicDir=path.join(__dirname,"public");
app.use(express.static(publicDir,{extensions:["html"]}));
app.use((req,res,next)=>{
 if(req.path.startsWith("/api/")||req.path==="/health")return next();
 const indexFile=path.join(publicDir,"index.html");
 if(fs.existsSync(indexFile))return res.sendFile(indexFile);
 next();
});
app.use((req,res)=>{
 if(req.path.startsWith("/api/"))return res.status(404).json({ok:false,message:"API endpoint not found."});
 res.status(404).send("Page not found.");
});
app.use((err,req,res,next)=>{
 console.error("SERVER ERROR:",err);
 if(res.headersSent)return next(err);
 res.status(500).json({ok:false,message:"Internal server error."});
});
app.listen(PORT,"0.0.0.0",()=>{
 console.log("AMBIKA PANE AI SERVER STARTED - PORT",PORT);
});
